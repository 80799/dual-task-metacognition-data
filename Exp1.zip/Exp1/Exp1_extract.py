"""input:Exp1data; output:extracted/Exp1_analysis.csv。"""
import csv
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

BASE = Path(__file__).resolve().parent
RAW = BASE / "Exp1data"
FIELDS = ["sub", "age", "acc0", "acc1", "acc2", "CRT1", "CRT2"]


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as file:
        return list(csv.DictReader(file))


def percent(correct, total):
    return (Decimal(correct) * 100 / Decimal(total)).quantize(
        Decimal("0.01"), rounding=ROUND_HALF_UP
    )


def main():
    results = []
    subjects = sorted(int(p.name.split("_")[0]) for p in RAW.glob("*_baseline_data.csv"))
    for sub in subjects:
        baseline = read_csv(RAW / f"{sub}_baseline_data.csv")
        result = {"sub": sub, "age": int(float(baseline[0]["age"]))}

        # 再认：只计算 recognition 行，百分比保留两位小数。
        for variable, condition in [("acc0", "baseline"), ("acc1", "visual"), ("acc2", "audio")]:
            rows = baseline if condition == "baseline" else read_csv(RAW / f"{sub}_{condition}_data.csv")
            trials = [row for row in rows if row["type"] == "recognition"]
            correct = sum(int(float(row["isCorrect"])) for row in trials)
            result[variable] = percent(correct, len(trials))

        # CRT：全部记录作为分母；undefined 未作答按未答对计算。
        for variable, condition in [("CRT1", "visual"), ("CRT2", "audio")]:
            trials = read_csv(RAW / f"{sub}_{condition}CRT.csv")
            correct = sum(row["iscorrect"].strip() == "1" for row in trials)
            result[variable] = percent(correct, len(trials))
        results.append(result)

    output = BASE / "Exp1_analysis.csv"
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(results)


if __name__ == "__main__":
    main()
