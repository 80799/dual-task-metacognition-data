"""
input:Exp2data; output:Exp2_analysis.csv。
condition：0=baseline，1=visual，2=audio。
"""
import csv
from decimal import Decimal, ROUND_HALF_UP
from itertools import combinations
from pathlib import Path

BASE = Path(__file__).resolve().parent
RAW = BASE / 'Exp2data'
FIELDS = ['sub', 'age', 'gender', 'JOL0', 'JOL1', 'JOL2',
          'acc0', 'acc1', 'acc2', 'corr_acc0', 'corr_acc1', 'corr_acc2',
          'JOLCalibration0', 'JOLCalibration1', 'JOLCalibration2',
          'gamma0', 'gamma1', 'gamma2', 'CRTacc1', 'CRTacc2']


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file))


def rounded(value):
    return value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def cue_name(value):
    return value.replace('\\', '/').split('/')[-1].strip().lower()


def gamma(pairs):
    # Goodman–Kruskal gamma = (同序对数 - 异序对数) / (同序对数 + 异序对数)。
    # 任一变量并列的对不计入；无可比较的对时输出空白。
    concordant = discordant = 0
    for (jol1, acc1), (jol2, acc2) in combinations(pairs, 2):
        product = (jol1 - jol2) * (acc1 - acc2)
        concordant += product > 0
        discordant += product < 0
    total = concordant + discordant
    return rounded(Decimal(concordant - discordant) / total) if total else ''


def main():
    results = []
    subjects = sorted(int(p.name.split('_')[0]) for p in RAW.glob('*_baseline_data.csv'))
    for sub in subjects:
        baseline = read_csv(RAW / f'{sub}_baseline_data.csv')
        result = {'sub': sub, 'age': int(float(baseline[0]['age'])), 'gender': ''}
        for condition, name in enumerate(['baseline', 'visual', 'audio']):
            rows = baseline if condition == 0 else read_csv(RAW / f'{sub}_{name}_data.csv')
            # 优先使用 baseline；为空时取其他条件中记录的性别。
            if result['gender'] == '':
                gender = next((r['gender'].strip() for r in rows if r['gender'].strip()), '')
                result['gender'] = {'女': 0, '男': 1}.get(gender, '')
            jol_rows = [r for r in rows if r['type'] == 'JOL']
            recognition = [r for r in rows if r['type'] == 'recognition']
            # JOL 与再认按同一刺激 cue 配对，不能按记录顺序配对。
            jol_by_cue = {cue_name(r['cue']): Decimal(r['JOL_score']) for r in jol_rows
                          if r['JOL_score'].strip().lower() not in ('', 'none', 'nan', 'null')}
            pairs = [(jol_by_cue[cue_name(r['cue'])], Decimal(r['isCorrect']))
                     for r in recognition if cue_name(r['cue']) in jol_by_cue]
            jol_mean = sum(jol_by_cue.values()) / len(jol_by_cue)
            accuracy = sum(Decimal(r['isCorrect']) for r in recognition) * 100 / len(recognition)
            # 校正：(正确率 - 25%) / (1 - 25%)。
            # 校准值为平均 JOL 减去校正正确率，先计算再四舍五入，不截断负值。
            corrected = (accuracy - 25) / Decimal('0.75')
            result[f'JOL{condition}'] = rounded(jol_mean)
            result[f'acc{condition}'] = rounded(accuracy)
            result[f'corr_acc{condition}'] = rounded(corrected)
            result[f'JOLCalibration{condition}'] = rounded(jol_mean - corrected)
            result[f'gamma{condition}'] = gamma(pairs)

        # CRT：所有记录均计入分母，undefined 未作答计为未答对。
        for condition, name in [(1, 'visual'), (2, 'audio')]:
            trials = read_csv(RAW / f'{sub}_{name}CRT.csv')
            correct = sum(r['iscorrect'].strip() == '1' for r in trials)
            result[f'CRTacc{condition}'] = rounded(Decimal(correct) * 100 / len(trials))
        results.append(result)

    output = BASE / 'Exp2_analysis.csv'
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(results)


if __name__ == '__main__':
    main()
