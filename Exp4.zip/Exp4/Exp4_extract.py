"""
input:Exp4data; output:Exp4_analysis.csv。
condition：0=baseline，1=visual，2=audio；gender：0=female，1=male。
"""
import csv
from decimal import Decimal, ROUND_HALF_UP
from itertools import combinations
from pathlib import Path

BASE = Path(__file__).resolve().parent
RAW = BASE / 'Exp4data'
FIELDS = ['sub', 'age', 'gender', 'CRT1', 'CRT2', 'JOLCalibration0', 'JOLCalibration1', 'JOLCalibration2', 'JOLResolution0', 'JOLResolution1', 'JOLResolution2', 'JolChoicegamma0', 'JolChoicegamma1', 'JolChoicegamma2', 'R1diffD0', 'R0diffD0', 'R1diffD1', 'R0diffD1', 'R1diffD2', 'R0diffD2', 'R1count0', 'R0count0', 'R1count1', 'R0count1', 'R1count2', 'R0count2']


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file))


def rounded(value):
    return value.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP) if value is not None else ''


def pair_key(row):
    # 用 cue 和 target 标识同一图片对。
    return tuple(row[k].replace(chr(92), '/').split('/')[-1].strip().lower()
                 for k in ('cue', 'target'))


def gamma(pairs):
    # 同序对与异序对；任一变量并列的对不计入。
    concordant = discordant = 0
    for (x1, y1), (x2, y2) in combinations(pairs, 2):
        product = (x1 - x2) * (y1 - y2)
        concordant += product > 0
        discordant += product < 0
    total = concordant + discordant
    return Decimal(concordant - discordant) / total if total else None


def mean(values):
    return sum(values) / len(values) if values else None


def main():
    results = []
    subjects = sorted(int(p.name.split('_')[0]) for p in RAW.glob('*_baseline_data.csv'))
    for sub in subjects:
        baseline = read_csv(RAW / f'{sub}_baseline_data.csv')
        result = {'sub': sub, 'age': int(float(baseline[0]['age'])), 'gender': ''}
        for condition, name in enumerate(['baseline', 'visual', 'audio']):
            rows = baseline if condition == 0 else read_csv(RAW / f'{sub}_{name}_data.csv')
            if result['gender'] == '':
                sex = next((r['gender'].strip() for r in rows if r['gender'].strip()), '')
                result['gender'] = {'女': 0, '男': 1}.get(sex, '')
            choices = {pair_key(r): r for r in rows if r['type'] == 'restudyChoice'}
            displayed = {pair_key(r) for r in rows if r['type'] == 'restudyDisplay'}
            recognition = [r for r in rows if r['type'] == 'recognition']
            unshown = [r for r in recognition if pair_key(r) not in displayed]

            # JOL 校准与分辨率：仅使用未再次呈现（display0）的图片对。
            # 校准 = 平均 JOL - (正确率百分数 - 20) / 0.8。
            jol = mean([Decimal(choices[pair_key(r)]['JOL_score']) for r in unshown])
            accuracy = mean([Decimal(r['isCorrect']) * 100 for r in unshown])
            calibration = jol - (accuracy - 20) / Decimal('0.8') if unshown else None
            result[f'JOLCalibration{condition}'] = rounded(calibration)
            result[f'JOLResolution{condition}'] = rounded(gamma([
                (Decimal(choices[pair_key(r)]['JOL_score']), Decimal(r['isCorrect']))
                for r in unshown]))

            # JOL 与复习选择的 gamma：使用全部 restudyChoice 图片对。
            result[f'JolChoicegamma{condition}'] = rounded(gamma([
                (Decimal(r['JOL_score']), Decimal(r['restudy'])) for r in choices.values()]))

            for restudy in (1, 0):
                # 固定 restudy 选择，计算 display1 正确率减去 display0 正确率。
                selected = [r for r in recognition
                            if choices[pair_key(r)]['restudy'] == str(restudy)]
                display1 = mean([Decimal(r['isCorrect']) * 100 for r in selected
                                 if pair_key(r) in displayed])
                display0 = mean([Decimal(r['isCorrect']) * 100 for r in selected
                                 if pair_key(r) not in displayed])
                difference = display1 - display0 if display1 is not None and display0 is not None else None
                result[f'R{restudy}diffD{condition}'] = rounded(difference)
                result[f'R{restudy}count{condition}'] = sum(r['restudy'] == str(restudy) for r in choices.values())

        # CRT 未作答计为未答对，所有记录保留在分母。
        for condition, name in [(1, 'visual'), (2, 'audio')]:
            trials = read_csv(RAW / f'{sub}_{name}CRT.csv')
            correct = sum(r['iscorrect'].strip() == '1' for r in trials)
            result[f'CRT{condition}'] = rounded(Decimal(correct) * 100 / len(trials))
        results.append(result)

    output = BASE /'Exp4_analysis.csv'
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('w', encoding='utf-8-sig', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(results)


if __name__ == '__main__':
    main()
